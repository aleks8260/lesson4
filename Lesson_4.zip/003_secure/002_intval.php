<?php
//intval — Возвращает целое значение переменной

    $number = intval('42.2');

    if ($number)
        echo 'Результат:'.$number;
?>