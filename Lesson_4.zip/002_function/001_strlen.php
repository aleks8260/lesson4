<?php
//strlen — Возвращает длину строки

$str = "Hellow world";
echo strlen($str);
?>