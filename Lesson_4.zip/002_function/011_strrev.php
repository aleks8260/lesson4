<?php
//strrev — Переворачивает строку задом наперед

echo strrev("Hello world!");
?>