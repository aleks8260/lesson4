<?php
// str_repeat — Возвращает повторяющуюся строку

echo str_repeat("-=", 10);
?>