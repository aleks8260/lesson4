<?php
//substr — Возвращает подстроку

    $rest = substr("abcdef", -1);   
    echo $rest; echo '<br>';
    $rest = substr("abcdef", -2); 
    echo $rest; echo '<br>';
    $rest = substr("abcdef", -3, 1);
    echo $rest; echo '<br>';
?>