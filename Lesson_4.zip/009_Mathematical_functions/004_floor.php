<?php
	$x = 38.85277;
	echo floor($x);
?>