<?php 

  $a = 35;
  $b = 10;
  echo sin($a)."<br>";
  echo cos($a)."<br>";
  echo abs($a)."<br>";
  echo log($b)."<br>";
?>