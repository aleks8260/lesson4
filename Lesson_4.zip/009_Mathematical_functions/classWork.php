<?php 

  $a = 25;

 // echo sin($a)."<br>";

  $b = sin($a);

  //echo $b."<br>";

  //echo pow($b,2)."<br>";

  $c = pow($b,2);

 // echo round($c, 0);

  echo $c;

?>