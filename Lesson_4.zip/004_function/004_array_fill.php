<?php
//array_fill — Заполняет массив значениями

    $a = array_fill(5, 6, 'banana');
    $b = array_fill(-2, 4, 'pear');
    print_r($a);
    print_r($b);

?>